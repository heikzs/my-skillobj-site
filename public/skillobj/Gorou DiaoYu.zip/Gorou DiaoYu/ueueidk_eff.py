import bpy
import os

TEXTURE_DIR = r"C:\Users\veizou\Desktop\zeroruka GI-Assets  SkillObj-Characters\Gorou\Gorou DiaoYu"   # <-- EDIT THIS

PLANE_BOTTOM = "Eff_Model_Plane_671"
PLANE_MIDDLE = "Eff_Model_Plane_682"
PLANE_TOP = "Eff_Model_Plane_663"

FPS = 24  
DISTORT_STRENGTH = 0.1
DEEP_BLUE = (0.12, 0.43, 0.85, 1.0)
LIGHT_CYAN = (0.50, 0.89, 1.00, 1.0)

TEX = {
    "normal": ("Eff_Normal_Fluid_02.png", "Non-Color"),
    "noise": ("Eff_Noise_13.png", "Non-Color"),
    "mask": ("Eff_Mask_06.png", "Non-Color"),
    "particles": ("Eff_Particles_02.png", "sRGB"),
}


def load_image(key):
    fname, cs = TEX[key]
    path = os.path.join(TEXTURE_DIR, fname)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Texture not found: {path}\nCheck TEXTURE_DIR at the top of the script.")
    img = bpy.data.images.load(path, check_existing=True)
    img.colorspace_settings.name = cs
    return img


def node(nt, ntype, x, y, **props):
    n = nt.nodes.new(ntype)
    n.location = (x, y)
    for k, v in props.items():
        setattr(n, k, v)
    return n


def image_node(nt, key, x, y):
    n = node(nt, "ShaderNodeTexImage", x, y)
    n.image = load_image(key)
    n.extension = "REPEAT"
    return n


def mapping_scroll(nt, vec_socket, scale, dx, dy, x, y):
    """Mapping node whose location scrolls with time via a driver."""
    m = node(nt, "ShaderNodeMapping", x, y)
    m.inputs["Scale"].default_value = (scale, scale, scale)
    nt.links.new(vec_socket, m.inputs["Vector"])
    for idx, speed in ((0, dx), (1, dy)):
        if speed != 0:
            fc = m.inputs["Location"].driver_add("default_value", idx)
            fc.driver.type = "SCRIPTED"
            fc.driver.expression = f"frame/{FPS}*{speed}"
    return m


def distorted_uv(nt, uv_socket, x, y):
    """UV + (scrolling fluid normal - 0.5) * strength"""
    fm = mapping_scroll(nt, uv_socket, 0.5, 0.03, 0.02, x, y)
    fl = image_node(nt, "normal", x + 200, y)
    nt.links.new(fm.outputs["Vector"], fl.inputs["Vector"])
    sub = node(nt, "ShaderNodeVectorMath", x + 500, y, operation="SUBTRACT")
    nt.links.new(fl.outputs["Color"], sub.inputs[0])
    sub.inputs[1].default_value = (0.5, 0.5, 0.5)
    sc = node(nt, "ShaderNodeVectorMath", x + 700, y, operation="SCALE")
    nt.links.new(sub.outputs[0], sc.inputs[0])
    sc.inputs[3].default_value = DISTORT_STRENGTH
    add = node(nt, "ShaderNodeVectorMath", x + 900, y, operation="ADD")
    nt.links.new(uv_socket, add.inputs[0])
    nt.links.new(sc.outputs[0], add.inputs[1])
    return add.outputs[0]


def caustic_sample(nt, vec_socket, scale, dx, dy, x, y):
    m = mapping_scroll(nt, vec_socket, scale, dx, dy, x, y)
    im = image_node(nt, "normal", x + 200, y)      # fluid texture instead of noise_13
    nt.links.new(m.outputs["Vector"], im.inputs["Vector"])
    return im.outputs["Color"]


def caustic_pattern(nt, vec_socket, scale_a, scale_b, dir_sign, x, y):
    """Curved ripple lines = contour lines of the smooth fluid texture."""
    a = caustic_sample(nt, vec_socket, scale_a, 0.0, 0.04 * dir_sign, x, y)
    b = caustic_sample(nt, vec_socket, scale_b, 0.02 * dir_sign, -0.03 * dir_sign, x, y - 300)
    avg = node(nt, "ShaderNodeMixRGB", x + 500, y - 150, blend_type="MIX")
    avg.inputs["Fac"].default_value = 0.5
    nt.links.new(a, avg.inputs["Color1"])
    nt.links.new(b, avg.inputs["Color2"])
    bw = node(nt, "ShaderNodeRGBToBW", x + 700, y - 150)
    nt.links.new(avg.outputs["Color"], bw.inputs["Color"])
    ramp = node(nt, "ShaderNodeValToRGB", x + 900, y - 150)
    cr = ramp.color_ramp
    cr.interpolation = "EASE"
    cr.elements[0].position = 0.44
    cr.elements[0].color = (0, 0, 0, 1)
    cr.elements[1].position = 0.50
    cr.elements[1].color = (1, 1, 1, 1)
    e = cr.elements.new(0.56)
    e.color = (0, 0, 0, 1)
    nt.links.new(bw.outputs["Val"], ramp.inputs["Fac"])
    return ramp.outputs["Color"]

def sparkle_layer(nt, uv_socket, vor_scale, radius, density, speed, x, y):
    m = mapping_scroll(nt, uv_socket, 1.0, 0.0, speed, x, y)
    m.inputs["Scale"].default_value = (2.5, 1.0, 1.0)
    vor = node(nt, "ShaderNodeTexVoronoi", x + 200, y)
    vor.feature = "F1"
    vor.inputs["Scale"].default_value = vor_scale
    nt.links.new(m.outputs["Vector"], vor.inputs["Vector"])

    # soft disc around each cell centre
    disc = node(nt, "ShaderNodeValToRGB", x + 450, y + 100)
    disc.color_ramp.interpolation = "EASE"
    disc.color_ramp.elements[0].position = 0.0
    disc.color_ramp.elements[0].color = (1, 1, 1, 1)
    disc.color_ramp.elements[1].position = radius
    disc.color_ramp.elements[1].color = (0, 0, 0, 1)
    nt.links.new(vor.outputs["Distance"], disc.inputs["Fac"])

    # pick which cells glow
    bw = node(nt, "ShaderNodeRGBToBW", x + 450, y - 150)
    nt.links.new(vor.outputs["Color"], bw.inputs["Color"])
    pick = node(nt, "ShaderNodeValToRGB", x + 650, y - 150)
    pick.color_ramp.elements[0].position = density
    pick.color_ramp.elements[0].color = (0, 0, 0, 1)
    pick.color_ramp.elements[1].position = density + 0.01
    pick.color_ramp.elements[1].color = (1, 1, 1, 1)
    nt.links.new(bw.outputs["Val"], pick.inputs["Fac"])

    mul = node(nt, "ShaderNodeMixRGB", x + 900, y, blend_type="MULTIPLY")
    mul.inputs["Fac"].default_value = 1.0
    nt.links.new(disc.outputs["Color"], mul.inputs["Color1"])
    nt.links.new(pick.outputs["Color"], mul.inputs["Color2"])
    return mul.outputs["Color"]

def new_material(name):
    mat = bpy.data.materials.get(name)
    if mat:
        bpy.data.materials.remove(mat)
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.node_tree.nodes.clear()
    try:
        mat.blend_method = "BLEND"
        mat.shadow_method = "NONE"
        mat.show_transparent_back = False
    except Exception:
        pass
    return mat


def assign(obj_name, mat):
    obj = bpy.data.objects.get(obj_name)
    if obj is None:
        print(f"[skip] object not found: {obj_name}")
        return
    if obj.data.users > 1:        
        obj.data = obj.data.copy()
    if len(obj.material_slots) == 0:
        obj.data.materials.append(mat)
    else:
        obj.material_slots[0].material = mat
    print(f"[ok] {obj_name} -> {mat.name}")

def build_bottom():
    mat = new_material("GenshinWater_Bottom_671")
    mat.blend_method = "OPAQUE"
    nt = mat.node_tree
    out = node(nt, "ShaderNodeOutputMaterial", 2600, 0)
    uv = node(nt, "ShaderNodeTexCoord", -1400, 0)
    dist = distorted_uv(nt, uv.outputs["UV"], -1200, 300)
    caus = caustic_pattern(nt, dist, 1.0, 1.6, 1, 0, 300)

    sep = node(nt, "ShaderNodeSeparateXYZ", -1000, -500)
    nt.links.new(uv.outputs["UV"], sep.inputs["Vector"])
    grad = node(nt, "ShaderNodeValToRGB", -800, -500)
    grad.color_ramp.elements[0].color = DEEP_BLUE
    grad.color_ramp.elements[1].color = LIGHT_CYAN
    nt.links.new(sep.outputs["Y"], grad.inputs["Fac"])

    tint = node(nt, "ShaderNodeMixRGB", 1500, 0, blend_type="MULTIPLY")
    tint.inputs["Fac"].default_value = 1.0
    nt.links.new(caus, tint.inputs["Color1"])
    tint.inputs["Color2"].default_value = LIGHT_CYAN

    final = node(nt, "ShaderNodeMixRGB", 1750, 0, blend_type="ADD")
    final.inputs["Fac"].default_value = 0.7
    nt.links.new(grad.outputs["Color"], final.inputs["Color1"])
    nt.links.new(tint.outputs["Color"], final.inputs["Color2"])

    em = node(nt, "ShaderNodeEmission", 2100, 0)
    em.inputs["Strength"].default_value = 0.7
    nt.links.new(final.outputs["Color"], em.inputs["Color"])
    nt.links.new(em.outputs["Emission"], out.inputs["Surface"]) 
    return mat


def build_middle():
    mat = new_material("GenshinWater_Middle_682")
    nt = mat.node_tree
    out = node(nt, "ShaderNodeOutputMaterial", 2600, 0)
    uv = node(nt, "ShaderNodeTexCoord", -1400, 0)
    dist = distorted_uv(nt, uv.outputs["UV"], -1200, 300)
    caus = caustic_pattern(nt, dist, 0.6, 0.9, -1, 0, 300)

    bw = node(nt, "ShaderNodeRGBToBW", 1500, 0)
    nt.links.new(caus, bw.inputs["Color"])
    alpha = node(nt, "ShaderNodeMath", 1700, 0, operation="MULTIPLY")
    nt.links.new(bw.outputs["Val"], alpha.inputs[0])
    alpha.inputs[1].default_value = 0.4

    em = node(nt, "ShaderNodeEmission", 1700, -250)
    em.inputs["Color"].default_value = LIGHT_CYAN
    em.inputs["Strength"].default_value = 1.8

    tr = node(nt, "ShaderNodeBsdfTransparent", 1700, 200)
    mix = node(nt, "ShaderNodeMixShader", 2100, 0)
    nt.links.new(alpha.outputs["Value"], mix.inputs["Fac"])
    nt.links.new(tr.outputs["BSDF"], mix.inputs[1])
    nt.links.new(em.outputs["Emission"], mix.inputs[2])
    nt.links.new(mix.outputs["Shader"], out.inputs["Surface"])
    return mat


def build_top():
    mat = new_material("GenshinWater_Top_663")
    nt = mat.node_tree
    out = node(nt, "ShaderNodeOutputMaterial", 2000, 0)
    uv = node(nt, "ShaderNodeTexCoord", -600, 0)

    pm = mapping_scroll(nt, uv.outputs["UV"], 1.0, 0.0, 0.02, -400, 200)
    pi = image_node(nt, "particles", -200, 200)
    nt.links.new(pm.outputs["Vector"], pi.inputs["Vector"])

    mi = image_node(nt, "mask", -200, -200)
    nt.links.new(uv.outputs["UV"], mi.inputs["Vector"])
    bw = node(nt, "ShaderNodeRGBToBW", 100, -200)
    nt.links.new(mi.outputs["Color"], bw.inputs["Color"])
    glow = node(nt, "ShaderNodeMixRGB", 350, -200, blend_type="MULTIPLY")
    glow.inputs["Fac"].default_value = 1.0
    nt.links.new(bw.outputs["Val"], glow.inputs["Color1"])
    glow.inputs["Color2"].default_value = LIGHT_CYAN

    glow_dim = node(nt, "ShaderNodeMixRGB", 600, -100, blend_type="MULTIPLY")
    glow_dim.inputs["Fac"].default_value = 1.0
    nt.links.new(glow.outputs["Color"], glow_dim.inputs["Color1"])
    glow_dim.inputs["Color2"].default_value = (0.4, 0.4, 0.4, 1.0)

    comb = node(nt, "ShaderNodeMixRGB", 850, 0, blend_type="ADD")
    comb.inputs["Fac"].default_value = 1.0
    s1 = sparkle_layer(nt, uv.outputs["UV"], 3.0, 0.22, 0.4, 0.02, -400, 500)
    s2 = sparkle_layer(nt, uv.outputs["UV"], 4.0, 0.3, 0.5, -0.03, -400, 900)
    sparks = node(nt, "ShaderNodeMixRGB", 600, 600, blend_type="ADD")
    sparks.inputs["Fac"].default_value = 1.0
    nt.links.new(s1, sparks.inputs["Color1"])
    nt.links.new(s2, sparks.inputs["Color2"])
    spark_tint = node(nt, "ShaderNodeMixRGB", 850, 600, blend_type="MULTIPLY")
    spark_tint.inputs["Fac"].default_value = 1.0
    nt.links.new(sparks.outputs["Color"], spark_tint.inputs["Color1"])
    spark_tint.inputs["Color2"].default_value = (2.0, 2.4, 2.5, 1.0)
    nt.links.new(spark_tint.outputs["Color"], comb.inputs["Color1"])
    nt.links.new(glow_dim.outputs["Color"], comb.inputs["Color2"])

    em = node(nt, "ShaderNodeEmission", 1100, 0)
    em.inputs["Strength"].default_value = 2.0
    nt.links.new(comb.outputs["Color"], em.inputs["Color"])
    tr = node(nt, "ShaderNodeBsdfTransparent", 1100, 200)
    add = node(nt, "ShaderNodeAddShader", 1500, 0)
    nt.links.new(tr.outputs["BSDF"], add.inputs[0])
    nt.links.new(em.outputs["Emission"], add.inputs[1])
    nt.links.new(add.outputs["Shader"], out.inputs["Surface"])
    return mat

assign(PLANE_BOTTOM, build_bottom())
assign(PLANE_MIDDLE, build_middle())
assign(PLANE_TOP, build_top())
print("Done. Press play on the timeline to see the water scroll.")
